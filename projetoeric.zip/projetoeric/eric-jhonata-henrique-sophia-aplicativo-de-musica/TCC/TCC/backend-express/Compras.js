class Compras{
    constructor(id_usuario) {
        this.id_usuario = id_usuario;
    }

    getIdUsuario() {
        return this.id_usuario;
    }

}
export default Compras;