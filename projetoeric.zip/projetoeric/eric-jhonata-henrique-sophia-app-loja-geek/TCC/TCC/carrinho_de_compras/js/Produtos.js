class Produtos {
    constructor(id_produto, nome, preco, descricao, ativo){
        this.id_produto = id_produto;
        this.nome = nome;
        this.descricao = descricao;
        this.ativo = ativo;

    }
}
export default Produtos;
